//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


func getDayOfWeek(_ today:String) -> Int?
{
    let formatter  = DateFormatter()
    formatter.dateFormat = "yyyy-MM-dd"
    guard let todayDate = formatter.date(from: today) else
    {
        return nil
        
    }
    let myCalendar = Calendar(identifier: .gregorian)
    let weekDay = myCalendar.component(.weekday, from: todayDate)
    return weekDay
}

func maxDayMonth(year: Int, month: Int) -> Int
{
    let dateComponents = DateComponents(year: year, month: month)
    let calendar = Calendar.current
    let date = calendar.date(from: dateComponents)!
    let range = calendar.range(of: .day, in: .month, for: date)!
    let numDays = range.count
    return numDays
}

func stringDate (strDate: String) -> Date
{
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "yyyy-MM-dd"
    let date = dateFormatter.date(from: strDate)
    return date!
    
}

func dateString (strDate: Date) -> String
{
    let formatter = DateFormatter()
    formatter.dateFormat = "yyyy-MM-dd"
    let myString = formatter.string(from: strDate)
    let yourDate = formatter.date(from: myString)
    formatter.dateFormat = "yyyy-MM-dd"
    let myStringafd = formatter.string(from: yourDate!)
    return myStringafd
}

func getnumberMonth(dateM: Date) -> Int
{
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "MM"
    let nameOfMonth = dateFormatter.string(from: dateM)
    return Int(nameOfMonth)!
}


extension Date: Strideable {
    public func advanced(by n: Int) -> Date {
        return Calendar.current.date(byAdding: .month, value: n, to: self) ?? self
    }
    
    public func distance(to other: Date) -> Int {
        return Calendar.current.dateComponents([.day], from: other, to: self).day ?? 0
    }
}

//Main

let firstDate = "2018-07-23"
let lastDate = "2099-04-23"

if let _ = getDayOfWeek(firstDate), let _ = getDayOfWeek(lastDate)
{
    let dateBegin = stringDate(strDate: firstDate)
    let dateEnd = stringDate(strDate: lastDate)
    var countSundays : Int = 0
    for date in dateBegin...dateEnd
    {
        let dateStringIterate = dateString(strDate: date)
        var arrDateDat = dateStringIterate.split(separator: "-")
        arrDateDat[2] = "31"
        let dateNew = arrDateDat.joined(separator: "-")
        let numberDay = getDayOfWeek(dateNew)
        
        if numberDay == 1
        {
            print("Fecha con domingo "+dateNew)
            countSundays += 1
        }
        
    }
    
    print("total de domingos: \(countSundays)")
}
else
{
    print("Formato de fecha incorrecto")
}


